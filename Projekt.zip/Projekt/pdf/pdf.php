<?php

require('fpdf.php');

// Utwórz połączenie
$conn = mysqli_connect('localhost', 'root', '', 'dra');

$sql = "SELECT * FROM `dra_users`;";
$result = mysqli_query($conn, $sql);

class PDF extends FPDF
{
    function Header()
    {
        // Wyśrodkowany nagłówek
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Wykaz uzytkownikow platformy DRA', 0, 1, 'C');
        $this->Ln(5); // Dodaj odstęp po nagłówku
    }

    function BasicTable($header, $data)
    {
        // Określ maksymalną szerokość strony (marginesy po obu stronach)
        $pageWidth = $this->GetPageWidth() - 20;

        // Określ minimalne i maksymalne szerokości kolumn
        $minWidth = 20;
        $maxWidth = $pageWidth / count($header);

        // Oblicz szerokości kolumn na podstawie danych
        $colWidths = array();
        foreach ($header as $i => $col) {
            $maxLength = strlen($col);
            foreach ($data as $row) {
                $maxLength = max($maxLength, strlen($row[$i]));
            }
            $colWidths[$i] = min(max($minWidth, $maxLength * 2), $maxWidth);
        }

        // Dostosuj szerokość kolumny Id i Email
        $originalIdWidth = $colWidths[0];
        $colWidths[0] /= 5.5;  // Id
        $colWidths[4] += ($originalIdWidth - $colWidths[0]); // Email

        // Wyśrodkuj tabelę
        $tableWidth = array_sum($colWidths);
        $this->SetX(($pageWidth - $tableWidth) / 2 + 10);

        // Nagłówek
        foreach ($header as $i => $col) {
            $this->Cell($colWidths[$i], 7, $col, 1, 0, 'C');
        }
        $this->Ln();

        // Dane
        foreach ($data as $row) {
            $this->SetX(($pageWidth - $tableWidth) / 2 + 10);
            foreach ($row as $i => $col) {
                $this->Cell($colWidths[$i], 6, $col, 1);
            }
            $this->Ln();
        }
    }
}

$pdf = new PDF();
$header = array('Id', 'Imie', 'Nazwisko', 'Telefon', 'Email', 'Login', 'Haslo', 'Miasto', 'Zdjecie', 'Opis');

// Dane
$data = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = array($row["id"], $row["imie"], $row["nazwisko"], $row["telefon"], $row["email"], $row["login"], $row["haslo"], $row["Miasto"], $row["Zdjęcie"], $row["Opis"]);
    }
}

$pdf->SetFont('Arial', '', 7);
$pdf->AddPage();
$pdf->BasicTable($header, $data);
$pdf->Output();
?>
